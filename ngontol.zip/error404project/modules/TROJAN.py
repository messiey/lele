from error404project import *


@bot.on(events.CallbackQuery(data=b'trojanws-trial'))
async def trojanwstrial(event):
		async def trojanwstrial_(event):
			z = db.execute("SELECT buttonname FROM trojanws").fetchall()
			do = []
			for i,k in zip(z[0::2], z[1::2]):
				print(i)
				print(k)
				do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
			if ( len(z) % 2 ) == True:
				do.append([Button.inline(z[-1][0])] )
			await event.edit(
buttons=do)
			async with bot.conversation(event.chat_id) as conv:
				conv = conv.wait_event(events.CallbackQuery)
				buttonname = await conv
				buttonname = buttonname.data.decode("utf-8")
				domain = db.execute("SELECT domain FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				param = f":6969/trial-trojan"
				r = requests.get("http://"+domain+param)
				if r.text != "error":
					try:
						db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(val["saldo"])-int(1),sender.id,))
						count = db.execute("SELECT counted FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
						db.execute("UPDATE trojanws SET counted = (?) WHERE domain = (?)",
						(int(count)+int(0),domain,))
						db.commit()
					except:
						pass
					today = DT.date.today()
					later = today + DT.timedelta(days=int(1))
					x = r.text.replace('[','').replace(']','').replace('"',
'').split(',')
					print(x)
					if len(list(x)) == 2:
						remarks = re.search("#(.*)",x[0]).group(1)
						domain = re.search("@(.*?):",x[0]).group(1)
						uuid = re.search("trojan://(.*?)@",x[0]).group(1)
						path = re.search("path=(.*?)&",x[0]).group(1)
						msg = f"""
**◇━━━━━━━━━━━━━◇**
**⟨ Xray/Trojan-Ws Account ⟩**
**◇━━━━━━━━━━━━━◇**
**» Remarks     :** `{remarks}`
**» Domain    :** `{domain}`
**» Port DNS  :** `443, 53`
**» port TLS  :** `443`
**» Port NTLS :** `80, 8080`
**» Path WS   :** `{path}`
**» User ID   :** `{uuid}`
**◇━━━━━━━━━━━━━◇**
**» Link WS    :** 
`{x[0].replace(" ","")}`
**◇━━━━━━━━━━━━━◇**
**» Link GRPC  :** 
`{x[1].replace(" ","")}`
**◇━━━━━━━━━━━━━◇**
**🗓️ Expired Until:** `{later}`
"""
					elif len(list(x)) == 1:
						remarks = re.search("#(.*)",x[0]).group(1)
						domain = re.search("@(.*?):",x[0]).group(1)
						uuid = re.search("trojan://(.*?)@",x[0]).group(1)
						path = re.search("path=(.*?)&",x[0]).group(1)
						msg = f"""
**◇━━━━━━━━━━━━━◇**
**⟨ Xray/Trojan-Ws Account ⟩**
**◇━━━━━━━━━━━━━◇**
**» Remarks     :** `{remarks}`
**» Domain    :** `{domain}`
**» Port DNS  :** `443, 53`
**» port TLS  :** `443`
**» Port NTLS :** `80, 8080`
**» Path WS   :** `{path}`
**» User ID   :** `{uuid}`
**◇━━━━━━━━━━━━━◇**
**» Link WS    :** 
`{x[0].replace(" ","")}`
**◇━━━━━━━━━━━━━◇**
**» Link GRPC  :** 
`{x[1].replace(" ","")}`
**◇━━━━━━━━━━━━━◇**
**🗓️ Expired Until:** `{later}`
"""
					await event.respond(msg)

		sender = await event.get_sender()
		val = valid(sender.id)
		db = get_db()
		x = db.execute("SELECT * FROM admin").fetchall()
		a = [v[0] for v in x]
		if val == "false":
			if sender.id not in a:
				await event.answer("Akses Ditolak")
			else:
				await trojanwstrial_(event)
		else:
			if str(val["saldo"]) == "0":
				await event.respond('**Saldo Kamu Kosong**')
			else:
				await trojanwstrial_(event)
				
@bot.on(events.CallbackQuery(data=b'create-trojanws'))
async def trojanws(event):
	async def trojanws_(event):
		z = db.execute("SELECT buttonname FROM trojanws").fetchall()
		do = []
		for i,k in zip(z[0::2], z[1::2]):
			print(i)
			print(k)
			do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
		if ( len(z) % 2 ) == True:
			do.append([Button.inline(z[-1][0])] )
		await event.edit(
buttons=do)
		async with bot.conversation(event.chat_id) as conv:
			conv = conv.wait_event(events.CallbackQuery)
			buttonname = await conv
			buttonname = buttonname.data.decode("utf-8")
		harga7 = db.execute("SELECT harga7 FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		harga = db.execute("SELECT harga FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		domain = db.execute("SELECT domain FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		quota = db.execute("SELECT quota FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		limitip = db.execute("SELECT limitip FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		lim = db.execute("SELECT limcounted FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		cont = db.execute("SELECT counted FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		z = requests.get(f"http://ip-api.com/json/{domain}?fields=country,region,city,timezone,isp").json()
		print(domain); print(harga); print(cont); print(lim); print(limitip)
		msg = f"""
** INFORMASI SERVER TROJAN **

** Server Name:** `{buttonname}`
** ISP:** `{z["isp"]}`
** Country:** `{z["country"]}`
** Domain:** `{domain}`
** Harga 7 Day:** `{harga7}`
** Harga 30 Day:** `{harga}`
** Total Akun Dibuat:** `{cont}/{lim}`


** Pilih Ya Untuk Lanjut...!! **

"""
		await event.edit(msg,buttons=[
[Button.inline(" Ya ","y"),Button.inline(" Tidak ","n")],
[Button.inline(" 🔙 Back To Menu ","menu")]])
		async with bot.conversation(event.chat_id) as con:
			con = con.wait_event(events.CallbackQuery)
			con = await con
		if con.data.decode("ascii") != "y" and con.data.decode("ascii") != "menu":
			await event.respond("**Dibatalkan.**")
		elif con.data.decode("ascii") == "y":
			async with bot.conversation(event.chat_id) as user:
					await event.edit("**Username: **")
					user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					user = await user
					user = user.message.message
					
			async with bot.conversation(event.chat_id) as exp:
				await event.respond("**Choose Expiry day**",
buttons=[
[Button.inline("7 Day","7")],
[Button.inline("30 Day","30")]])
				exp = exp.wait_event(events.CallbackQuery)
				exp = await exp
				exp = exp.data.decode("ascii")
			if lim == cont:
				await event.respond("**Server Full**")
			elif int(val["saldo"]) < harga7:
				await event.respond("**Saldo Anda Tidak cukup**")
			else:
				if exp == "7":
					min = harga7
				if exp == "30":
					min = harga
				param = f":6969/trojan-create?user={user}&quota={quota}&limitip={limitip}&exp={exp}"
				r = requests.get("http://"+domain+param)
				if r.text != "error":
					try:
						db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(val["saldo"])-int(min),sender.id,))
						count = db.execute("SELECT counted FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
						db.execute("UPDATE trojanws SET counted = (?) WHERE domain = (?)",
						(int(count)+int(1),domain,))
						db.commit()
					except:
						pass
					today = DT.date.today()
					later = today + DT.timedelta(days=int(exp))
					x = r.text.replace('[','').replace(']','').replace('"',
'').split(',')
					print(x)
					if len(list(x)) == 2:
						remarks = re.search("#(.*)",x[0]).group(1)
						domain = re.search("@(.*?):",x[0]).group(1)
						uuid = re.search("trojan://(.*?)@",x[0]).group(1)
						path = re.search("path=(.*?)&",x[0]).group(1)
						msg = f"""
**◇━━━━━━━━━━━━━◇**
**⟨ Xray/Trojan-Ws Account ⟩**
**◇━━━━━━━━━━━━━◇**
**» Remarks     :** `{remarks}`
**» Domain    :** `{domain}`
**» Port DNS  :** `443, 53`
**» port TLS  :** `443`
**» Port NTLS :** `80, 8080`
**» Path WS   :** `{path}`
**» User ID   :** `{uuid}`
**◇━━━━━━━━━━━━━◇**
**» Link WS    :** 
`{x[0].replace(" ","")}`
**◇━━━━━━━━━━━━━◇**
**» Link GRPC  :** 
`{x[1].replace(" ","")}`
**◇━━━━━━━━━━━━━◇**
**» Format OpenClash :** `https://{domain}:81/trojan-{user}.txt`
**◇━━━━━━━━━━━━━◇**
**🗓️ Expired Until:** `{later}`
"""

					elif len(list(x)) == 1:
						remarks = re.search("#(.*)",x[0]).group(1)
						domain = re.search("@(.*?):",x[0]).group(1)
						uuid = re.search("trojan://(.*?)@",x[0]).group(1)
						path = re.search("path=(.*?)&",x[0]).group(1)
						msg = f"""
**◇━━━━━━━━━━━━━◇**
**⟨ Xray/Trojan-Ws Account ⟩**
**◇━━━━━━━━━━━━━◇**
**» Remarks     :** `{remarks}`
**» Domain    :** `{domain}`
**» Port DNS  :** `443, 53`
**» port TLS  :** `443`
**» Port NTLS :** `80, 8080`
**» Path WS   :** `{path}`
**» User ID   :** `{uuid}`
**◇━━━━━━━━━━━━━◇**
**» Link WS    :** 
`{x[0].replace(" ","")}`
**◇━━━━━━━━━━━━━◇**
**» Link GRPC  :** 
`{x[1].replace(" ","")}`
**◇━━━━━━━━━━━━━◇**
**» Format OpenClash :** `https://{domain}:81/trojan-{user}.txt`
**◇━━━━━━━━━━━━━◇**
**🗓️ Expired Until:** `{later}`
"""
					await event.respond(msg)
					
					dat = {
				"email":val["email"],
                                "protocol":"Trojan-ws",
                                "server":domain,
                                "exp":str(later)}
					await notifs(dat, event)
				else:
					await event.respond("""
_**ERROR**_

**PROBABLY :-** `Username Already Exist`, `Server Error`
""")
		

	sender = await event.get_sender()
	val = valid(sender.id)
	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	data = event.data.decode("ascii").split("-")[0]
	if val == "false":
		if sender.id not in a:
			await event.answer("Akses Ditolak")
		else:
			val = {"saldo":"100000000"}
			await trojanws_(event)
	else:
		await trojanws_(event)

@bot.on(events.CallbackQuery(data=b'trwsmenu'))
async def trojanwsmenu(event):
	sender = await event.get_sender()
	val = valid(sender.id)
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	ser = namastrws()
	har = hargastrws()
	har = hargastrwss()
	serv = []
	for x, y, a in zip(ser, har, harr):
		print(x, y, a)
		serv.append(f"** {x}  7 Day** `Rp.{a}`\n")
		serv.append(f"** {x}  30 Day** `Rp.{y}`\n")
	if val == "false":
		if sender.id in a:
			msg = f"""
Trojan Menu
- Trojan gRPC TLS
- Trojan TCP TLS
- Trojan WS TLS
- Trojan WS Non-TLS

Rules:
- Max 2 Login
- Max 3x Peringatan (Penggantian UUID)
- Peringatan 4x Banned

Info Harga:
** **
{"".join(serv)}


"""
			await event.edit(msg, buttons=[
[Button.inline(" CREATED TROJAN ","create-trojanws"),
Button.inline(" CREATED TRIAL TROJAN ","trojanws-trial")],

[Button.inline("🔙 Back To Menu",f"menu")]])
		else:
			await event.answer("Akses Ditolak ❌")
	else:
		msg = f"""
Trojan Menu
- Trojan gRPC TLS
- Trojan TCP TLS
- Trojan WS TLS
- Trojan WS Non-TLS

Rules:
- Max 2 Login
- Max 3x Peringatan (Penggantian UUID)
- Peringatan 4x Banned

Info Harga:
** **
{"".join(serv)}


"""
		await event.edit(msg, buttons=[
[Button.inline(" CREATED TROJAN ","create-trojanws"),
Button.inline(" CREATED TRIAL TROJAN ","trojanws-trial")],

[Button.inline("🔙 Back To Menu",f"menu")]])
