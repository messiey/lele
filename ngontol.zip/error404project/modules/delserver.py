from error404project import *

@bot.on(events.CallbackQuery(data=b'delssh'))
async def delssh(event):
	async def delssh_(event):
		z = db.execute("SELECT domain FROM ssh").fetchall()
		do = []
		do = []
		for i,k in zip(z[0::2], z[1::2]):
			print(i)
			print(k)
			do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
		if ( len(z) % 2 ) == True:
			do.append([Button.inline(z[-1][0])] )
		await event.edit(
buttons=do)
		async with bot.conversation(event.chat_id) as conv:
			conv = conv.wait_event(events.CallbackQuery)
			domain = await conv
			domain = domain.data.decode("ascii")
		buttonname = db.execute("SELECT buttonname FROM ssh WHERE domain = (?)",(domain,)).fetchone()[0]
		print(domain); print(buttonname)
		msg = f"""
**━━━━━━━━━━━━━━━━**
** Informasi Server **
**━━━━━━━━━━━━━━━━**
**🔰 Server Name:** `{buttonname}`
**🔰 Domain:** `{domain}`
**━━━━━━━━━━━━━━━━**
** Yakin Ingin Menghapus Server? **
**━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg,buttons=[
[Button.inline("Ya","y"),Button.inline("Tidak","n")],
[Button.inline("«« Back To Menu ««","menu")]])
		async with bot.conversation(event.chat_id) as con:
			con = con.wait_event(events.CallbackQuery)
			con = await con
		if con.data.decode("ascii") == "y":
			db.execute("DELETE FROM ssh WHERE domain = (?)",
			(domain,))
			db.commit()
			await event.respond("**Berhasil menghapus Server**")
		elif con.data.decode("ascii") != "y" and con.data.decode("ascii") != "menu":
			await event.respond("**Dibatalkan.**")

	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	sender = await event.get_sender()
	if sender.id in a:
		await delssh_(event)
	else:
		await event.answer("Akses Ditolak!")
		
		
@bot.on(events.CallbackQuery(data=b'deltrws'))
async def deltrws(event):
	async def deltrws_(event):
		z = db.execute("SELECT domain FROM trojanws").fetchall()
		do = []
		do = []
		for i,k in zip(z[0::2], z[1::2]):
			print(i)
			print(k)
			do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
		if ( len(z) % 2 ) == True:
			do.append([Button.inline(z[-1][0])] )
		await event.edit(
buttons=do)
		async with bot.conversation(event.chat_id) as conv:
			conv = conv.wait_event(events.CallbackQuery)
			domain = await conv
			domain = domain.data.decode("ascii")
		buttonname = db.execute("SELECT buttonname FROM trojanws WHERE domain = (?)",(domain,)).fetchone()[0]
		print(domain); print(buttonname)
		msg = f"""
**━━━━━━━━━━━━━━━━**
** Informasi Server **
**━━━━━━━━━━━━━━━━**
**🔰 Server Name:** `{buttonname}`
**🔰 Domain:** `{domain}`
**━━━━━━━━━━━━━━━━**
** Yakin Ingin Menghapus Server? **
**━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg,buttons=[
[Button.inline("Ya","y"),Button.inline("Tidak","n")],
[Button.inline("«« Back To Menu ««","menu")]])
		async with bot.conversation(event.chat_id) as con:
			con = con.wait_event(events.CallbackQuery)
			con = await con
		if con.data.decode("ascii") == "y":
			db.execute("DELETE FROM trojanws WHERE domain = (?)",
			(domain,))
			db.commit()
			await event.respond("**Berhasil menghapus Server**")
		elif con.data.decode("ascii") != "y" and con.data.decode("ascii") != "menu":
			await event.respond("**Dibatalkan.**")

	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	sender = await event.get_sender()
	if sender.id in a:
		await deltrws_(event)
	else:
		await event.answer("Akses Ditolak!")
		
@bot.on(events.CallbackQuery(data=b'delvm'))
async def delvm(event):
	async def delvm_(event):
		z = db.execute("SELECT domain FROM vmess").fetchall()
		do = []
		for i,k in zip(z[0::2], z[1::2]):
			print(i)
			print(k)
			do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
		if ( len(z) % 2 ) == True:
			do.append([Button.inline(z[-1][0])] )
		await event.edit(
buttons=do)
		async with bot.conversation(event.chat_id) as conv:
			conv = conv.wait_event(events.CallbackQuery)
			domain = await conv
			domain = domain.data.decode("ascii")
		buttonname = db.execute("SELECT buttonname FROM vmess WHERE domain = (?)",(domain,)).fetchone()[0]
		print(domain); print(buttonname)
		msg = f"""
**━━━━━━━━━━━━━━━━**
** Informasi Server **
**━━━━━━━━━━━━━━━━**
**🔰 Server Name:** `{buttonname}`
**🔰 Domain:** `{domain}`
**━━━━━━━━━━━━━━━━**
** Yakin Ingin Menghapus Server? **
**━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg,buttons=[
[Button.inline("Ya","y"),Button.inline("Tidak","n")],
[Button.inline("«« Back To Menu ««","menu")]])
		async with bot.conversation(event.chat_id) as con:
			con = con.wait_event(events.CallbackQuery)
			con = await con
		if con.data.decode("ascii") == "y":
			db.execute("DELETE FROM vmess WHERE domain = (?)",
			(domain,))
			db.commit()
			await event.respond("**Berhasil menghapus Server**")
		elif con.data.decode("ascii") != "y" and con.data.decode("ascii") != "menu":
			await event.respond("**Dibatalkan.**")

	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	sender = await event.get_sender()
	if sender.id in a:
		await delvm_(event)
	else:
		await event.answer("Akses Ditolak!")

@bot.on(events.CallbackQuery(data=b'delgfw'))
async def deltrgfw(event):
	async def deltrgfw_(event):
		z = db.execute("SELECT domain FROM trojangfw").fetchall()
		do = []
		for i,k in zip(z[0::2], z[1::2]):
			print(i)
			print(k)
			do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
		if ( len(z) % 2 ) == True:
			do.append([Button.inline(z[-1][0])] )
		await event.edit(
buttons=do)
		async with bot.conversation(event.chat_id) as conv:
			conv = conv.wait_event(events.CallbackQuery)
			domain = await conv
			domain = domain.data.decode("ascii")
		buttonname = db.execute("SELECT buttonname FROM trojangfw WHERE domain = (?)",(domain,)).fetchone()[0]
		print(domain); print(buttonname)
		msg = f"""
**━━━━━━━━━━━━━━━━**
** Informasi Server **
**━━━━━━━━━━━━━━━━**
**🔰 Server Name:** `{buttonname}`
**🔰 Domain:** `{domain}`
**━━━━━━━━━━━━━━━━**
** Yakin Ingin Menghapus Server? **
**━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg,buttons=[
[Button.inline("Ya","y"),Button.inline("Tidak","n")],
[Button.inline("«« Back To Menu ««","menu")]])
		async with bot.conversation(event.chat_id) as con:
			con = con.wait_event(events.CallbackQuery)
			con = await con
		if con.data.decode("ascii") == "y":
			db.execute("DELETE FROM trojangfw WHERE domain = (?)",
			(domain,))
			db.commit()
			await event.respond("**Berhasil menghapus Server**")
		elif con.data.decode("ascii") != "y" and con.data.decode("ascii") != "menu":
			await event.respond("**Dibatalkan.**")

	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	sender = await event.get_sender()
	if sender.id in a:
		await deltrgfw_(event)
	else:
		await event.answer("Akses Ditolak!")

@bot.on(events.CallbackQuery(data=b'deltrgo'))
async def deltrgo(event):
	async def deltrgo_(event):
		z = db.execute("SELECT domain FROM trojango").fetchall()
		do = []
		for i,k in zip(z[0::2], z[1::2]):
			print(i)
			print(k)
			do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
		if ( len(z) % 2 ) == True:
			do.append([Button.inline(z[-1][0])] )
		await event.edit(
buttons=do)
		async with bot.conversation(event.chat_id) as conv:
			conv = conv.wait_event(events.CallbackQuery)
			domain = await conv
			domain = domain.data.decode("ascii")
		buttonname = db.execute("SELECT buttonname FROM trojango WHERE domain = (?)",(domain,)).fetchone()[0]
		print(domain); print(buttonname)
		msg = f"""
**━━━━━━━━━━━━━━━━**
** Informasi Server **
**━━━━━━━━━━━━━━━━**
**🔰 Server Name:** `{buttonname}`
**🔰 Domain:** `{domain}`
**━━━━━━━━━━━━━━━━**
** Yakin Ingin Menghapus Server? **
**━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg,buttons=[
[Button.inline("Ya","y"),Button.inline("Tidak","n")],
[Button.inline("«« Back To Menu ««","menu")]])
		async with bot.conversation(event.chat_id) as con:
			con = con.wait_event(events.CallbackQuery)
			con = await con
		if con.data.decode("ascii") == "y":
			db.execute("DELETE FROM trojango WHERE domain = (?)",
			(domain,))
			db.commit()
			await event.respond("**Berhasil menghapus Server**")
		elif con.data.decode("ascii") != "y" and con.data.decode("ascii") != "menu":
			await event.respond("**Dibatalkan.**")

	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	sender = await event.get_sender()
	if sender.id in a:
		await deltrgo_(event)
	else:
		await event.answer("Akses Ditolak!")
@bot.on(events.CallbackQuery(data=b'delserver'))
async def dels(event):
	sender = await event.get_sender()
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	if sender.id in a:
		z = await event.edit(buttons=[
[Button.inline(" DELETE SERVER VMESS ","delvm")],
[Button.inline(" DELETE SERVER SSH ","delssh"),
Button.inline(" DELETE SERVER TROJAN ","deltrws")],
[Button.inline(" DELETE SERVER TROJAN-GW ","delgfw"),
Button.inline(" DELETE SERVER TROJAN-GO ","deltrgo")],
[Button.inline(" 🔙 Back To Menu","menu")]])
		if not z:
			await event.respond(msg,buttons=[
[Button.inline(" DELETE SERVER VMESS ","delvm")],
[Button.inline(" DELETE SERVER SSH ","delssh"),
Button.inline(" DELETE SERVER TROJAN ","deltrws")],
[Button.inline(" DELETE SERVER TROJAN-GW ","delgfw"),
Button.inline(" DELETE SERVER TROJAN-GO ","deltrgo")],
[Button.inline(" 🔙 Back To Menu","menu")]])

	else:
		val = valid(sender.id)
		if val == "false":
			try:
				await event.answer("**Akses ditolak ❌**")
			except:
				await event.respond("**Akses Ditolak ❌**")