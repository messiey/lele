from error404project import *
from importlib import import_module
from error404project.modules import ALL_MODULES
for module_name in ALL_MODULES:
        imported_module = import_module("error404project.modules." + module_name)
if __name__ == "__main__":
	bot.loop.run_until_complete(sbot())
	aapp.run()
