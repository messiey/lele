from agin import *
		
@bot.on(events.CallbackQuery(data=b'ssh-trial'))
async def trial(event):
		async def trial_(event):
			z = db.execute("SELECT buttonname FROM ssh").fetchall()
			do = []
			for i,k in zip(z[0::2], z[1::2]):
				print(i)
				print(k)
				do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
			if ( len(z) % 2 ) == True:
				do.append([Button.inline(z[-1][0])] )
			await event.edit(
buttons=do)
			async with bot.conversation(event.chat_id) as conv:
				conv = conv.wait_event(events.CallbackQuery)
				buttonname = await conv
				buttonname = buttonname.data.decode("utf-8")
				harga = db.execute("SELECT harga FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				portwsntls = db.execute("SELECT portwsntls FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				domain = db.execute("SELECT domain FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				nsdomain = db.execute("SELECT ns FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				pubkey = db.execute("SELECT pubkey FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				#link = db.execute("SELECT link FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				#portwstls = db.execute("SELECT portwstls FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				#portdb = db.execute("SELECT portdb FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				limitip = db.execute("SELECT limitip FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				param = f"/trial-ssh"
				trial = requests.get("http://"+domain+":6969/trial-ssh").text.split(":")
				exp = 1
				today = DT.date.today()
				later = today + DT.timedelta(days=int(exp))
				print(trial)
				msg = f"""
**◇━━━━━━━━━━━━━◇**
**⟨ TRIAL SSH OVPN Account ⟩**
**◇━━━━━━━━━━━━━◇**
**» Username         :** `{trial[0].strip()}`
**» Password         :** `{trial[1]}`
**◇━━━━━━━━━━━━━◇**
**» Host             :** `{domain}`
**» Host Slowdns     :** `{nsdomain}`
**» Port OpenSSH     :** `443, 80, 22`
**» Port UdpSSH      :** `1-65535`
**» Port DNS         :** `443, 53 ,22`
**» Port Dropbear    :** `443, 109`
**» Port Dropbear WS :** `443, 109`
**» Port SSH WS      :** `80, 8080`
**» Port SSH SSL WS  :** `443`
**» Port SSL/TLS     :** `443`
**» Port OVPN WS SSL :** `443`
**» Port OVPN SSL    :** `443`
**» Port OVPN TCP    :** `443, 1194`
**» Port OVPN UDP    :** `2200`
**» Proxy Squid      :** `3128`
**» BadVPN UDP       :** `7100, 7300, 7300`
**» Pub Key          :** `{pubkey}`
**◇━━━━━━━━━━━━━◇**
**» Payload WSS      :** `GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {domain}[crlf]Upgrade: websocket[crlf][crlf]`
**◇━━━━━━━━━━━━━◇**
** Payload WSS HTTPS :**
`GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {domain}[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]`
**◇━━━━━━━━━━━━━◇**
**» Link OpenVPN     :** `https://{domain}:81`
**◇━━━━━━━━━━━━━◇**
**» Save Link Account:** `https://{domain}:81/ssh-{trial[0].strip()}.txt`
**◇━━━━━━━━━━━━━◇**
**🗓 Expired Until:** `{later}`
"""

				await event.respond(msg)
				dat = {"email":val["email"],
                                "protocol":"SSH-trial",
                                "server":domain,
                                "exp":str(later)}
				await notifstrr(dat,event)

		sender = await event.get_sender()
		val = valid(sender.id)
		db = get_db()
		x = db.execute("SELECT * FROM admin").fetchall()
		a = [v[0] for v in x]
		if val == "false":
			if sender.id not in a:
				await event.answer("Akses Ditolak")
			else:
				await trial_(event)
		else:
			if str(val["saldo"]) == "0":
				await event.respond('**Saldo Kamu Kosong**')
			else:
				await trial_(event)
				
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def ssh(event):
	async def ssh_(event):
		z = db.execute("SELECT buttonname FROM ssh").fetchall()
		do = []
		for i,k in zip(z[0::2], z[1::2]):
			print(i)
			print(k)
			do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
		if ( len(z) % 2 ) == True:
			do.append([Button.inline(z[-1][0])] )
		await event.edit(
buttons=do)
		async with bot.conversation(event.chat_id) as conv:
			conv = conv.wait_event(events.CallbackQuery)
			buttonname = await conv
			buttonname = buttonname.data.decode("utf-8")
		harga7 = db.execute("SELECT harga7 FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		harga = db.execute("SELECT harga FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		portwsntls = db.execute("SELECT portwsntls FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		domain = db.execute("SELECT domain FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		nsdomain = db.execute("SELECT ns FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		pubkey = db.execute("SELECT pubkey FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		#link = db.execute("SELECT link FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		#portwstls = db.execute("SELECT portwstls FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		#portdb = db.execute("SELECT portdb FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		limitip = db.execute("SELECT limitip FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		lim = db.execute("SELECT limcounted FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		cont = db.execute("SELECT counted FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		z = requests.get(f"http://ip-api.com/json/{domain}?fields=country,region,city,timezone,isp").json()
		print(domain); print(harga); print(cont); print(lim); print(limitip)
		msg = f"""
** INFORMASI SERVER SSH **

** Server Name:** `{buttonname}`
** ISP:** `{z["isp"]}`
** Country:** `{z["country"]}`
** Domain:** `{domain}`
** Harga 7 Day:** `{harga7}`
** Harga 30 Day:** `{harga}`
** Total Akun Dibuat:** `{cont}/{lim}`


** Pilih Ya Untuk Lanjut...!! **

"""
		await event.edit(msg,buttons=[
[Button.inline(" Ya ","y"),Button.inline(" Tidak ","n")],
[Button.inline(" 🔙 ","menu")]])
		async with bot.conversation(event.chat_id) as con:
			con = con.wait_event(events.CallbackQuery)
			con = await con
		if con.data.decode("ascii") != "y" and con.data.decode("ascii") != "menu":
			await event.respond("**Dibatalkan.**")
		elif con.data.decode("ascii") == "y":
			async with bot.conversation(event.chat_id) as user:
					await event.edit("**Username: **")
					user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					user = await user
					user = user.message.message
			async with bot.conversation(event.chat_id) as pw:
					await event.respond("**Password: **")
					pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					pw = await pw
					pw = pw.message.message.replace(" ","")
			async with bot.conversation(event.chat_id) as exp:
				await event.respond("**Choose Expiry day**",
buttons=[
[Button.inline("7 Day","7")],
[Button.inline("30 Day","30")]])
				exp = exp.wait_event(events.CallbackQuery)
				exp = await exp
				exp = exp.data.decode("ascii")
			if lim == cont:
				await event.respond("**Server Full**")
			elif int(val["saldo"]) < harga7:
				await event.respond("**Saldo Anda Tidak cukup**")
			else:
				if exp == "7":
					min = harga7
				if exp == "30":
					min = harga

				param = f"/adduser/exp?user={user}&password={pw}&exp={exp}&limitip={limitip}"
				r = requests.get("http://"+domain+":6969"+param).text
				if r == "success":
					try:
						db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(val["saldo"])-int(min),sender.id,))
						count = db.execute("SELECT counted FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
						db.execute("UPDATE ssh SET counted = (?) WHERE domain = (?)",
						(int(count)+int(1),domain,))
						db.commit()
					except Exception as e:
						print(str(e))
						pass
					today = DT.date.today()
					later = today + DT.timedelta(days=int(exp))
					msg = f"""

**◇━━━━━━━━━━━━━◇**
**⟨  SSH OVPN Account ⟩**
**◇━━━━━━━━━━━━━◇**
**» Username         :** `{user.strip()}`
**» Password         :** `{pw.strip()}`
**◇━━━━━━━━━━━━━◇**
**» Host             :** `{domain}`
**» Host Slowdns     :** `{nsdomain}`
**» Port OpenSSH     :** `443, 80, 22`
**» Port UdpSSH      :** `1-65535`
**» Port DNS         :** `443, 53 ,22`
**» Port Dropbear    :** `443, 109`
**» Port Dropbear WS :** `443, 109`
**» Port SSH WS      :** `80, 8080`
**» Port SSH SSL WS  :** `443`
**» Port SSL/TLS     :** `443`
**» Port OVPN WS SSL :** `443`
**» Port OVPN SSL    :** `443`
**» Port OVPN TCP    :** `443, 1194`
**» Port OVPN UDP    :** `2200`
**» Proxy Squid      :** `3128`
**» BadVPN UDP       :** `7100, 7300, 7300`
**» Pub Key          :** `{pubkey}`
**◇━━━━━━━━━━━━━◇**
**» Payload WSS      :** `GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {domain}[crlf]Upgrade: websocket[crlf][crlf]`
**◇━━━━━━━━━━━━━◇**
** Payload WSS HTTPS :**
`GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {domain}[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]`
**◇━━━━━━━━━━━━━◇**
**» Link OpenVPN     :** `https://{domain}:81`
**◇━━━━━━━━━━━━━◇**
**» Save Link Account:** `https://{domain}:81/ssh-{user.strip()}.txt`
**◇━━━━━━━━━━━━━◇**
**🗓 Expired Until:** `{later}`
"""
				
					await event.respond(msg)
					
					dat = {
				"email":val["email"],
                                "protocol":"SSH",
                                "server":domain,
                                "exp":str(later)}
					await notifs(dat, event)
				else:
					await event.respond("""
_**ERROR**_

**PROBABLY :-** `Username Already Exist`, `Server Error`
""")
		

	sender = await event.get_sender()
	val = valid(sender.id)
	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	data = event.data.decode("ascii").split("-")[0]
	if val == "false":
		if sender.id not in a:
			await event.answer("Akses Ditolak")
		else:
			val = {"saldo":"100000000"}
			await ssh_(event)
	else:
		await ssh_(event)
		
@bot.on(events.CallbackQuery(data=b'ssh-menu'))
async def smenu(event):
	sender = await event.get_sender()
	val = valid(sender.id)
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	ser = namash()
	har = hargash()
	harr = hargassh()
	serv = []
	for x, y, a in zip(ser, har, harr):
		print(x, y, a)
		serv.append(f"** {x}  7 Day** `Rp.{a}`\n")
		serv.append(f"** {x}  30 Day** `Rp.{y}`\n")
	if val == "false":
		if sender.id in a:
			msg = f"""
SSH/OpenVPN Menu
- SSH
- SSH SSL
- SSH WS
- SSH UDP
- SSH WS-SSL
- SlowDNS
- OpenVPN
- BadVPN UDPgw

Rules:
- Max 2 Login
- Max 3x Peringatan (Ganti Password)
- Peringatan 4x Banned

Info Harga :

{"".join(serv)}

"""
			await event.edit(msg, buttons=[
[Button.inline(" CREATED SSH ","create-ssh"),
Button.inline(" CREATED TRIAL SSH ","ssh-trial")],

[Button.inline("🔙 Back To Menu",f"menu")]])
		else:
			await event.answer("❌")
	else:
		msg = f"""
SSH/OpenVPN Menu
- SSH
- SSH SSL
- SSH WS
- SSH UDP
- SSH WS-SSL
- SlowDNS
- OpenVPN
- BadVPN UDPgw

Rules:
- Max 2 Login
- Max 3x Peringatan (Ganti Password)
- Peringatan 4x Banned

Info Harga :

{"".join(serv)}

"""
		await event.edit(msg, buttons=[
[Button.inline(" CREATED SSH ","create-ssh"),
Button.inline(" CREATED TRIAL SSH ","ssh-trial")],

[Button.inline("🔙 Back To Menu",f"menu")]])
