import requests
import json
import base64
import random
import string
from datetime import datetime, timedelta
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, ConversationHandler
from telegram import ReplyKeyboardMarkup

# Masukkan token GitHub dan informasi repositori GitHub
github_token = "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"
repository_owner = "messiey"
repository_name = "lele"
dns_record_name = "error"

# Header untuk permintaan HTTP ke GitHub API dengan menggunakan token akses personal
headers = {
    'Authorization': f'token {github_token}',
    'Content-Type': 'application/json',
}

# URL repositori GitHub
url = f'https://api.github.com/repos/{repository_owner}/{repository_name}/contents/{dns_record_name}'

# Inisialisasi bot
updater = Updater("6670926441:AAHQnHzPxJaVy0WZD4kov4C3ZFPj8pqBjMk", use_context=True)
dp = updater.dispatcher

# Status konversasi untuk menangani input IP dan durasi
IP, DURATION = range(2)

# Pilihan masa aktif yang akan ditampilkan kepada pengguna
duration_choices = ["30 hari", "60 hari", "90 hari"]

# Fungsi untuk menghasilkan username acak
def generate_random_username(length=8):
    characters = string.ascii_lowercase + string.digits
    return ''.join(random.choice(characters) for i in range(length))

# Fungsi untuk menambahkan atau memperbarui catatan IP di GitHub
def add_or_update_ip(vps_ip, username, expiration_date):
    current_date = datetime.now().strftime("%Y-%m-%d")  # Waktu saat ini

    # Mendapatkan isi file terlebih dahulu
    response = requests.get(url, headers=headers)
    if response.status_code != 200:
        print(f'Gagal mendapatkan isi file. Kode status: {response.status_code}')
        return
    
    decoded_content = base64.b64decode(response.json()['content']).decode('utf-8')

    # Memeriksa apakah IP sudah terdaftar sebelumnya
    if vps_ip in decoded_content:
        parts = decoded_content.split('\n')
        for i, part in enumerate(parts):
            if vps_ip in part:
                parts[i] = f"### {username} {expiration_date} {vps_ip}"

        updated_content = '\n'.join(parts)
    else:
        formatted_entry = f'### {username} {expiration_date} {vps_ip}'
        updated_content = decoded_content + '\n' + formatted_entry

    # Mengonversi konten yang sudah diperbarui ke base64
    updated_content_base64 = base64.b64encode(updated_content.encode('utf-8')).decode('utf-8')

    # Menyiapkan data untuk dikirimkan ke GitHub API
    data = {
        'message': f'Update VPS IP - {current_date}',
        'content': updated_content_base64,
        'sha': response.json()['sha'],
    }

    # Mengirimkan permintaan PUT ke GitHub API untuk memperbarui konten file
    update_response = requests.put(url, headers=headers, data=json.dumps(data))

    if update_response.status_code == 200:
        print(f'IP VPS berhasil ditambahkan atau diperbarui di GitHub - {current_date}.')
    else:
        print(f'Gagal menambahkan atau memperbarui IP VPS. Kode status: {update_response.status_code}')
        print(f'Response: {update_response.text}')

    # Mencetak isi setelah penambahan atau pembaruan IP
    print(f'Isi setelah penambahan atau pembaruan IP:\n{updated_content}')

# Fungsi untuk menangani perintah /renew
def renew(update, context):
    update.message.reply_text("Halo! Silakan masukkan IP VPS Anda.")

    # Mengganti status konversasi menjadi IP
    return IP

# Fungsi untuk menangani masukan IP VPS
def handle_ip(update, context):
    user_data = context.user_data
    # Mendapatkan pesan yang dikirim oleh pengguna
    user_message = update.message.text

    # Memeriksa apakah pesan yang dikirim adalah IP yang valid
    if is_valid_ip(user_message):
        user_data['vps_ip'] = user_message

        # Menampilkan pilihan masa aktif
        reply_markup = ReplyKeyboardMarkup([duration_choices], one_time_keyboard=True)
        update.message.reply_text("Pilih masa aktif yang diinginkan:", reply_markup=reply_markup)
        
            # Mengganti status konversasi menjadi DURATION
    return DURATION
else:
    update.message.reply_text("IP yang dimasukkan tidak valid. Silakan coba lagi.")

    # Mengganti status konversasi menjadi IP
    return IP
    
#Fungsi untuk menangani pilihan masa aktif
def handle_duration(update, context):
user_data = context.user_data
# Mendapatkan pesan yang dikirim oleh pengguna
user_message = update.message.text

# Memeriksa apakah pilihan masa aktif valid
if user_message in duration_choices:
    # Mendapatkan tanggal kedaluwarsa berdasarkan pilihan masa aktif
    duration = int(user_message.split()[0])  # Mengambil angka dari pilihan (misal: 30 dari "30 hari")
    expiration_date = (datetime.now() + timedelta(days=duration)).strftime("%Y-%m-%d")  # Menambahkan durasi ke waktu saat ini

    # Mendapatkan username acak
    username = generate_random_username()

    # Menambah atau memperbarui catatan IP di GitHub
    add_or_update_ip(user_data['vps_ip'], username, expiration_date)

    update.message.reply_text(f"IP VPS Anda ({user_data['vps_ip']}) berhasil diperbarui.\n\nUsername: {username}\nTanggal Kedaluwarsa: {expiration_date}")
else:
    update.message.reply_text("Pilihan masa aktif tidak valid. Silakan coba lagi.")

# Mengakhiri konversasi
return ConversationHandler.END

# Fungsi untuk memeriksa apakah string adalah IP yang valid
def is_valid_ip(ip):
    # Implementasikan logika validasi IP di sini
    # Contoh sederhana: memeriksa apakah string sesuai dengan format IPv4
    parts = ip.split('.')
    if len(parts) == 4:
        try:
            return all(0 <= int(part) <= 255 for part in parts)
        except ValueError:
            return False
    return False

#Handler untuk perintah /start
dp.add_handler(CommandHandler("start", start))

#Handler untuk perintah /renew
dp.add_handler(CommandHandler("renew", renew))

#Handler untuk input IP VPS
dp.add_handler(MessageHandler(Filters.text & (~Filters.command), handle_ip))

#Handler untuk input pilihan masa aktif
dp.add_handler(MessageHandler(Filters.text & (~Filters.command), handle_duration))

#Memulai bot
updater.start_polling()
updater.idle()