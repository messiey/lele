import subprocess
import requests
import json
import base64
import random
import string
from datetime import datetime, timedelta
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, ConversationHandler
from telegram import ReplyKeyboardMarkup


def main():
    # Panggil skrip registrasi.py
    print("Running regis.py...")
    subprocess.run(["python3", "regis.py"])

    # Panggil skrip renew.py
    print("Running renew.py...")
    subprocess.run(["python3", "renew.py"])

    # Panggil skrip delete.py
    print("Running delete.py...")
    subprocess.run(["python3", "delete.py"])

if __name__ == "__main__":
    main()
