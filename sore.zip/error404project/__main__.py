from error404project import *
from importlib import import_module
from error404project.modules import ALL_MODULES
for module_name in ALL_MODULES:
        imported_module = import_module("error404project.modules." + module_name)
bot.run_until_disconnected()

usr.local.bin

